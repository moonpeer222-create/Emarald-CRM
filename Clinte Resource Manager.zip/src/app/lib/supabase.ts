// Supabase Client Configuration
import { createClient, SupabaseClient, User, Session } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// Database Types
export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          phone: string;
          full_name: string;
          role: 'master_admin' | 'admin' | 'agent' | 'customer';
          status: 'active' | 'inactive' | 'suspended';
          photo_url: string | null;
          created_by: string | null;
          created_at: string;
          updated_at: string;
          last_login: string | null;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['users']['Insert']>;
      };
      cases: {
        Row: {
          id: string;
          case_number: string;
          customer_id: string | null;
          customer_name: string;
          phone: string;
          email: string | null;
          cnic: string | null;
          passport: string | null;
          country: string;
          job_type: string;
          status: 'new' | 'documents' | 'medical' | 'visa' | 'ticketing' | 'completed' | 'rejected';
          priority: 'low' | 'medium' | 'high' | 'urgent';
          agent_id: string | null;
          agent_name: string | null;
          total_fee: number;
          paid_amount: number;
          created_by: string | null;
          created_at: string;
          updated_at: string;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['cases']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['cases']['Insert']>;
      };
      payments: {
        Row: {
          id: string;
          case_id: string;
          amount: number;
          method: 'cash' | 'bank' | 'easypaisa' | 'jazzcash' | 'card';
          receipt_number: string | null;
          description: string | null;
          collected_by: string | null;
          payment_date: string;
          created_at: string;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['payments']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['payments']['Insert']>;
      };
      documents: {
        Row: {
          id: string;
          case_id: string;
          name: string;
          type: string;
          file_url: string;
          file_size: number | null;
          status: 'pending' | 'verified' | 'rejected';
          notes: string | null;
          uploaded_by: string | null;
          verified_by: string | null;
          uploaded_at: string;
          verified_at: string | null;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['documents']['Row'], 'id' | 'uploaded_at'>;
        Update: Partial<Database['public']['Tables']['documents']['Insert']>;
      };
      timeline_events: {
        Row: {
          id: string;
          case_id: string;
          event_type: 'status' | 'payment' | 'document' | 'medical' | 'note';
          title: string;
          description: string | null;
          created_by: string | null;
          created_at: string;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['timeline_events']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['timeline_events']['Insert']>;
      };
      notes: {
        Row: {
          id: string;
          case_id: string;
          text: string;
          important: boolean;
          author_id: string | null;
          author_name: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['notes']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['notes']['Insert']>;
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: 'case' | 'payment' | 'document' | 'deadline' | 'agent' | 'system';
          priority: 'low' | 'medium' | 'high' | 'critical';
          title: string;
          message: string;
          read: boolean;
          actionable: boolean;
          action_url: string | null;
          action_label: string | null;
          created_at: string;
          expires_at: string | null;
          metadata: Record<string, any>;
        };
        Insert: Omit<Database['public']['Tables']['notifications']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['notifications']['Insert']>;
      };
      attendance: {
        Row: {
          id: string;
          user_id: string;
          check_in: string | null;
          check_out: string | null;
          status: 'present' | 'late' | 'absent' | 'leave' | null;
          leave_type: 'sick' | 'casual' | 'annual' | 'unpaid' | null;
          notes: string | null;
          approved_by: string | null;
          date: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['attendance']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['attendance']['Insert']>;
      };
    };
  };
}

// Supabase Client Singleton
let supabaseClient: SupabaseClient<Database> | null = null;

export function getSupabaseClient(): SupabaseClient<Database> {
  if (supabaseClient) {
    return supabaseClient;
  }

  const supabaseUrl = `https://${projectId}.supabase.co`;
  const supabaseAnonKey = publicAnonKey;

  supabaseClient = createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });

  return supabaseClient;
}

// Export singleton instance
export const supabase = getSupabaseClient();

// Helper Types
export type DbUser = Database['public']['Tables']['users']['Row'];
export type DbCase = Database['public']['Tables']['cases']['Row'];
export type DbPayment = Database['public']['Tables']['payments']['Row'];
export type DbDocument = Database['public']['Tables']['documents']['Row'];
export type DbTimelineEvent = Database['public']['Tables']['timeline_events']['Row'];
export type DbNote = Database['public']['Tables']['notes']['Row'];
export type DbNotification = Database['public']['Tables']['notifications']['Row'];
export type DbAttendance = Database['public']['Tables']['attendance']['Row'];

// Helper Functions
export async function getCurrentUser(): Promise<User | null> {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function getCurrentUserProfile(): Promise<DbUser | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', user.id)
    .single();

  if (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }

  return data;
}

export async function getSession(): Promise<Session | null> {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

export function onAuthStateChange(callback: (user: User | null) => void) {
  return supabase.auth.onAuthStateChange((event, session) => {
    callback(session?.user || null);
  });
}

// Check if user has permission
export async function hasPermission(
  requiredRole: DbUser['role'] | DbUser['role'][]
): Promise<boolean> {
  const profile = await getCurrentUserProfile();
  if (!profile) return false;

  const roles = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
  return roles.includes(profile.role);
}

// Check if current user is admin
export async function isAdmin(): Promise<boolean> {
  return hasPermission(['master_admin', 'admin']);
}

// Check if current user is master admin
export async function isMasterAdmin(): Promise<boolean> {
  return hasPermission('master_admin');
}